package com.example.mu04_labinfo4404.teste;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by mu04_labinfo4404 on 20/06/2018.
 */
public class Main22ActivityImplTest {
    @Test
    public void onContextClick() throws Exception {

    }

}