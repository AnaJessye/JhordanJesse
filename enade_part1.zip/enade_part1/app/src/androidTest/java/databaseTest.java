import android.database.sqlite.SQLiteDatabase;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by mu04_labinfo4404 on 15/06/2018.
 */
public class databaseTest {
    @Test
    public void onCreate() throws Exception {



    }

    @Test
    public void onUpgrade() throws Exception {

    }


}